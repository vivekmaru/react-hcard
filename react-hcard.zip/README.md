## hCard builder created in React

This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

